async function fetchTodos() {
    const response = await fetch('/api/todos');
    const todos = await response.json();
    const listElement = document.getElementById('todo-list');
    listElement.innerHTML = '';
    todos.forEach(todo => {
        const item = document.createElement('div');
        item.className = 'todo-item';
        const titleClass = todo.completed ? 'completed' : '';
        item.innerHTML = `
            <button class="btn-del" onclick="event.stopPropagation(); deleteTodo(${todo.id})">削除</button>
            <div class="${titleClass}" onclick="toggleTodo(${todo.id}, ${todo.completed})">${todo.title}</div>
        `;
        listElement.appendChild(item);
    });
}

async function toggleTodo(id, currentStatus) {
    await fetch(`/api/todos/${id}`, { 
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed: !currentStatus })
    });
    fetchTodos();
}

async function addTodo() {
    const input = document.getElementById('todoTitle');
    if (!input.value) return;
    await fetch('/api/todos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: input.value, completed: false })
    });
    input.value = '';
    fetchTodos();
}

async function deleteTodo(id) {
    if (!confirm('削除しますか？')) return;
    await fetch(`/api/todos/${id}`, { method: 'DELETE' });
    fetchTodos();
}

// 初期読み込み
fetchTodos();